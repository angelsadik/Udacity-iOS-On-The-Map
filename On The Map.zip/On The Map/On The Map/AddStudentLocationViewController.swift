//
//  AddStudentLocationViewController.swift
//  On The Map
//
//  Created by Malak Sadik on 31/12/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import UIKit
import CoreLocation

class AddStudentLocationViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var cityLocationField: UITextField!
    
    @IBOutlet weak var linkField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Cancel", style: .done, target: self, action: #selector(self.cancelTapped(_:)))
        
        cityLocationField.delegate = self
        linkField.delegate = self
    }
    
    @objc private func cancelTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func findLocationClicked(_ sender: Any) {
        guard let location = cityLocationField.text,
            let mediaLink = linkField.text,
            location != "", mediaLink != "" else {
                showAlert(title: "Missing information", message: "Please fill both fields and try again")
                return
        }
        //creating a new student
        var studentLocation = StudentInfo.init(firstName: nil, lastName: nil, latitude: 0, longitude: 0, mapString: location, mediaURL: mediaLink, objectId: "", uniqueKey: LoginViewController.uniqueKey, createdAt: "", updatedAt: "")
        
        //An activity indicator is displayed during geocoding, and returns to normal state on completion.
        let ai = UIActivityIndicatorView(style: .gray)
        self.view.addSubview(ai)
        self.view.bringSubviewToFront(ai)
        ai.center = self.view.center
        ai.hidesWhenStopped = true
        ai.startAnimating()
        
        // Use CLGeocoder's function named `geocodeAddressString` to convert location's `mapString` to coordinates
        CLGeocoder().geocodeAddressString(studentLocation.mapString!){(placeMarks,error) in
            // Call `ai.stopAnimating()` first thing in the completionHandler
            ai.stopAnimating()
            // Extract the first location from Place Marks array
            guard let marks = placeMarks?.first?.location else {
                self.showAlert(title: "Error", message: "Could not geocode your location. Please try again")
                return
            }
            // Copy studentLocation into a new object and save latitude and longitude in the new object's properties `latitude` and `longitude`
            
            studentLocation.longitude = Double((marks.coordinate.longitude))
            studentLocation.latitude = Double((marks.coordinate.latitude))
            
            // Call performSegue using `addMapSegue` identifier and pass `location` as the sender
            self.performSegue(withIdentifier: "addMapSegue", sender: studentLocation)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addMapSegue", let vc = segue.destination as? ConfirmLocationViewController {
            vc.location = (sender as! StudentInfo)
        }
    }
    
    func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    
    public func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}
