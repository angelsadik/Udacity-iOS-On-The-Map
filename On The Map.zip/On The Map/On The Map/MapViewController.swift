//
//  MapViewController.swift
//  On The Map
//
//  Created by Malak Sadik on 28/12/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: ContainerViewController, MKMapViewDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    override var students: [StudentInfo] {
        didSet {
            updatePins()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        
        loadStudentLocations()
        
    }
    
    func updatePins() {

        let locationsArray = students
        var annotations = [MKPointAnnotation] ()
        
        //Loop through the array of structs and get locations data from it so they can be displayed on the map
        for student in locationsArray {
            
            let long = CLLocationDegrees (student.longitude ?? 0)
            let lat = CLLocationDegrees (student.latitude ?? 0)
            
            let coords = CLLocationCoordinate2D (latitude: lat, longitude: long)
            
            //Get the media URL and call it mediaURL, if it's nil its value should be " ", for that use Nil-Coalescing Operator (??)
            // var name != nil ? userName : defaultName
            //ex. var name = userName ?? defaultName
            let mediaURL = student.mediaURL ?? " " //student url
            
            //Get the first name
            let first = student.firstName ?? " "
            
            //Get the last name
            let last = student.lastName ?? " "
            // Here we create the annotation and set its coordiate, title, and subtitle properties
            let annotation = MKPointAnnotation()
            annotation.coordinate = coords
            annotation.title = "\(first) \(last)"
            annotation.subtitle = mediaURL
            
            annotations.append (annotation)
        }
        self.mapView.addAnnotations (annotations)
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        
        return pinView
    }
    
    // This delegate method is implemented to respond to taps. It opens the system browser
    // to the URL specified in the annotationViews subtitle property.
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        if control == view.rightCalloutAccessoryView {
            let app = UIApplication.shared
            if let toOpen = view.annotation?.subtitle! {
                app.open(URL(string: toOpen)!, options: [:], completionHandler: nil)
            }
        }
    }
}
