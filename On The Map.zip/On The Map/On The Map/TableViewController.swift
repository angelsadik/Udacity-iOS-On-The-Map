//
//  ViewController.swift
//  On The Map
//
//  Created by Malak Sadik on 28/12/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import UIKit

class TableViewController: ContainerViewController, UITableViewDataSource, UITableViewDelegate
{

    @IBOutlet weak var studentsTableView: UITableView!
    
    override var students: [StudentInfo] {
        didSet {
            studentsTableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        studentsTableView.delegate = self
        studentsTableView.dataSource = self
        
        loadStudentLocations()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "studentTableViewCell", for: indexPath)
        
        let studentObject = self.students[(indexPath as NSIndexPath).row]
        
        // set cell defaults
        cell.textLabel?.text = studentObject.firstName
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return students.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        if let studentUrl = URL(string: self.students[(indexPath as NSIndexPath).row].mediaURL!) {
                UIApplication.shared.open(studentUrl)
            }
    }
}

