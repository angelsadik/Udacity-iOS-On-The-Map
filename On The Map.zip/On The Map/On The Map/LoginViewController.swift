//
//  LoginViewController.swift
//  On The Map
//
//  Created by Malak Sadik on 28/12/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var userNameField: UITextField!
    
    @IBOutlet weak var userPassField: UITextField!
    
    public static var sessionId: String?
    public static var uniqueKey: String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    @IBAction func loginButton(_ sender: Any) {
        
        let username = userNameField.text
        let password = userPassField.text
        
        if (username!.isEmpty) || (password!.isEmpty) {
            
            let requiredInfoAlert = UIAlertController (title: "Fill the required fields", message: "Please fill both the email and password", preferredStyle: .alert)
            
            requiredInfoAlert.addAction(UIAlertAction (title: "OK", style: .default, handler: { _ in
                return
            }))
            
            self.present (requiredInfoAlert, animated: true, completion: nil)
            
        } else {
            
            postSession(username, password){(loginSuccess, key, error) in
                //Execute the entire code inside the completion body on the main thread asynchronous
                DispatchQueue.main.async {
                    
                    if error != nil {
                        let errorAlert = UIAlertController(title: "Erorr performing request", message: "There was an error performing your request", preferredStyle: .alert )
                        
                        errorAlert.addAction(UIAlertAction (title: "OK", style: .default, handler: { _ in
                            return
                        }))
                        self.present(errorAlert, animated: true, completion: nil)
                        return
                    }
                    
                    if !loginSuccess {
                        let loginAlert = UIAlertController(title: "Erorr logging in", message: "incorrect email or password", preferredStyle: .alert )
                        
                        loginAlert.addAction(UIAlertAction (title: "OK", style: .default, handler: { _ in
                            return
                        }))
                        self.present(loginAlert, animated: true, completion: nil)
                    }
                    else {
                        self.performSegue(withIdentifier: "logged", sender: nil)
                     
                        //In on the map, you need to use the key to call a function in the API class to get the user's first name and last name, but here we're just printing the key. So, in your app, instead of printing it, you'll call that function and be passing it as an argument to that function.
                        print ("the key is \(key)")
                    }
                }
            }
        }
    }
    
    func postSession (_ username : String!, _ password : String!, completion: @escaping (Bool, String, Error?)->()) {
        
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = "{\"udacity\": {\"username\": \"\(username!)\", \"password\": \"\(password!)\"}}".data(using: .utf8)
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil {
                // Call the completion handler and send the error so it can be handled on the UI, also call "return" so the code next to this block won't be executed
                completion (false, "", error)
                return
            }
            
            //Get the status code to check if the response is OK or not
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode else {
                
                // Call the completion handler and send the error so it can be handled on the UI, also call "return" so the code next to this block won't be executed (you need to call return in let guard's else body anyway)
                let statusCodeError = NSError(domain: NSURLErrorDomain, code: 0, userInfo: nil)
                completion (false, "", statusCodeError)
                return
            }
            
            if statusCode >= 200  && statusCode < 300 {
                
                //Skipping the first 5 characters
                let range = Range(5..<data!.count)
                let newData = data?.subdata(in: range) /* subset response data! */
                
                //Print the data to see it and know you'll parse it (this can be removed after you complete building the app)
                print (String(data: newData!, encoding: .utf8)!)
                
                //Get an object based on the received data in JSON format
                let loginJsonObject = try! JSONSerialization.jsonObject(with: newData!, options: [])
                
                //Convert the object to a dictionary
                let loginDictionary = loginJsonObject as? [String : Any]
                
                //Get the unique key of the user
                let accountDictionary = loginDictionary? ["account"] as? [String : Any]
                LoginViewController.uniqueKey = accountDictionary? ["key"] as? String ?? " "
                
                //Get the id of the user
                let sessionDict = loginDictionary?["session"] as? [String: Any]
                LoginViewController.sessionId = sessionDict? ["id"] as? String
                
                completion (true, LoginViewController.uniqueKey!, nil)//loginSuccess, key, error
            } else {
                //call the completion handler properly
                completion(false, "", nil)
            }
        }
        //Start the task
        task.resume()
    }
    
}
    func deleteSession(completion: @escaping (String?)->Void) {
        
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
        request.httpMethod = "DELETE"
        var xsrfCookie: HTTPCookie? = nil
        let sharedCookieStorage = HTTPCookieStorage.shared
        for cookie in sharedCookieStorage.cookies! {
        if cookie.name == "XSRF-TOKEN" { xsrfCookie = cookie }
        }
        if let xsrfCookie = xsrfCookie {
        request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
        }
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
        if error != nil { // Handle error…
            return
        }
        let range = Range(5..<data!.count)
        let newData = data?.subdata(in: range) /* subset response data! */
        DispatchQueue.main.async {
                completion(nil)
        }
        print(String(data: newData!, encoding: .utf8)!)
        }
        task.resume()
    }
    

