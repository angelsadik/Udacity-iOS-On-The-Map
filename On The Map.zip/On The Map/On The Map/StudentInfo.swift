//
//  StudentInfo.swift
//  On The Map
//
//  Created by Malak Sadik on 28/12/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import Foundation

//Note how the properties' names in the struct are exactly equal to the keys names in the JSON response. This is necessary so we can eventually decode the response to an array of objects of this struct.

struct StudentInfo : Codable { // so we can use decode/ from json string to object

    var firstName : String?
    var lastName : String?
    var latitude : Double?
    var longitude : Double?
    var mapString : String?
    var mediaURL : String?
    var objectId : String?
    var uniqueKey : String?
    var createdAt : String?
    var updatedAt : String?
    
}

 func getStudentsLocations (completion: @escaping ([StudentInfo]?, Error?) -> ()) {
    var request = URLRequest (url: URL (string: "https://parse.udacity.com/parse/classes/StudentLocation?limit=100&order=-updatedAt")!)
    
    request.addValue("QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr", forHTTPHeaderField: "X-Parse-Application-Id")
    
    request.addValue("QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY", forHTTPHeaderField: "X-Parse-REST-API-Key")
    
    let session = URLSession.shared
    let task = session.dataTask(with: request) {data, response, error in
        if error != nil {
            // Call the completion handler and send the error so it can be handled on the UI, also call "return" so the code next to this block won't be executed
        }
        //Print the data to see it and know you'll parse it
        print (String(data: data!, encoding: .utf8)!)
        
        guard let statusCode = (response as? HTTPURLResponse)?.statusCode else {
            // Call the completion handler and send the error so it can be handled on the UI, also call "return" so the code next to this block won't be executed (you need to call return in let guard's else body anyway)
            let statusCodeError = NSError(domain: NSURLErrorDomain, code: 0, userInfo: nil)
            completion (nil, statusCodeError)
            return
        }
        
        if statusCode >= 200 && statusCode < 300 {
            
            //Get an object based on the received data in JSON format
            let jsonObject = try! JSONSerialization.jsonObject(with: data!, options: [])
            
            //Convert jsonObject to a dictionary
            guard let jsonDictionary = jsonObject as? [String:Any] else {return}
            //get the locations (associated with the key “results") and store it into a constant named resultArray
            let resultArray = jsonDictionary["results"] as? [[String:Any]]
            //Check if the result array is nil using guard let, if it's return, otherwise continue
            guard let array = resultArray else {return}
            
            //Convert the array above into a valid JSON Data object (so you can use that object to decode it into an array of student locations) and name it dataObject
            let dataObject = try! JSONSerialization.data(withJSONObject: array, options: .prettyPrinted)
            
            //Use JSONDecoder to convert dataObject to an array of structs
            let studentsLocations = try! JSONDecoder().decode([StudentInfo].self, from: dataObject)
            
            
            completion (studentsLocations, nil)
        }
    }
    
    task.resume()
}

func postStudentLocation(_ location: StudentInfo, completion: @escaping (String?)->Void) {
    // Note that you'll need to send (uniqueKey, firstName, lastName) along with the post request. These information should be obtained upon logging in and they should be saved somewhere (Ex. AppDelegate or in this class)
    //To create a *new* student location:
    guard let studentId = location.uniqueKey else {
        completion("Invalid key or URL")
        return
        
    }
    var request = URLRequest(url: URL(string: "https://parse.udacity.com/parse/classes/StudentLocation")!)
    request.httpMethod = "POST"
    request.addValue("QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr", forHTTPHeaderField: "X-Parse-Application-Id")
    request.addValue("QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY", forHTTPHeaderField: "X-Parse-REST-API-Key")
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    let str = "{\"uniqueKey\": \"\(studentId)\", \"firstName\": \"\(location.firstName ?? "John")\", \"lastName\": \"\(location.lastName ?? "Doe")\",\"mapString\": \"\(location.mapString!)\", \"mediaURL\": \"\(location.mediaURL!)\",\"latitude\": \(location.latitude!), \"longitude\": \(location.longitude!)}"
    request.httpBody = str.data(using: .utf8)
    print ("*****"+str)
    
    let session = URLSession.shared
    let task = session.dataTask(with: request) { data, response, error in
        var errString: String?
        if let statusCode = (response as? HTTPURLResponse)?.statusCode{//request sent successfully
            if statusCode >= 400 {
                errString = "Could not post student location"
            }
        } else { //request failed to sent
            errString = "Check your Internet connection"
        }
        DispatchQueue.main.async {
            completion(errString)
        }
        print("Succefully added "+String(data: data!, encoding: .utf8)!)
        
    }
    task.resume()
    
}

func putStudentLocation(_ location: StudentInfo, completion: @escaping (String?)->Void) {
    //To *update* an existing student location:
    let urlString = "https://parse.udacity.com/parse/classes/StudentLocation/8ZExGR5uX8"
    let url = URL(string: urlString)
    var request = URLRequest(url: url!)
    request.httpMethod = "PUT"
    request.addValue("QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr", forHTTPHeaderField: "X-Parse-Application-Id")
    request.addValue("QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY", forHTTPHeaderField: "X-Parse-REST-API-Key")
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.httpBody = "{\"uniqueKey\": \(location.uniqueKey), \"firstName\": \(location.firstName), \"lastName\": \(location.lastName),\"mapString\": \(location.mapString), \"mediaURL\": \(location.mediaURL),\"latitude\": \(location.latitude), \"longitude\": \(location.longitude)}".data(using: .utf8)
    let session = URLSession.shared
    let task = session.dataTask(with: request) { data, response, error in
        if error != nil { // Handle error…
            return
        }
        print(String(data: data!, encoding: .utf8)!)
    }
    task.resume()
}
