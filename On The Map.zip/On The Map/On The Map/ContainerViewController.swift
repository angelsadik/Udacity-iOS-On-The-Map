//
//  ContainerViewController.swift
//  On The Map
//
//  Created by Malak Sadik on 07/01/2019.
//  Copyright © 2019 Malak Sadik. All rights reserved.
//

import UIKit

class ContainerViewController: UIViewController {

    var students: [StudentInfo] = [] {
        didSet {
            loadStudentLocations()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // create and set logout button
        let plusButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(self.addLocationClicked(_:)))
        let refreshButton = UIBarButtonItem(barButtonSystemItem: .refresh, target: self, action: #selector(self.refreshLocationsClicked(_:)))
        let logoutButton = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(self.logoutClicked(_:)))
        
        navigationItem.rightBarButtonItems = [plusButton, refreshButton]
        navigationItem.leftBarButtonItem = logoutButton

    }
    
    @objc private func addLocationClicked(_ sender: Any) {
        let navController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddStudentNavigationController") as! UINavigationController // to the navigation controller so we can start over after completing adding
        present(navController, animated: true, completion: nil)
    }
    
    @objc private func refreshLocationsClicked(_ sender: Any) {
        loadStudentLocations()
    }
     public func loadStudentLocations() {
        getStudentsLocations () {(studentsLocations, error) in //function from student struct
            DispatchQueue.main.async {
                
                if error != nil {
                    let errorAlert = UIAlertController(title: "Erorr performing request", message: "There was an error performing your request", preferredStyle: .alert )
                    
                    errorAlert.addAction(UIAlertAction (title: "OK", style: .default, handler: { _ in
                        return
                    }))
                    self.present(errorAlert, animated: true, completion: nil)
                    return
                }
                
                guard let locationsArray = studentsLocations else {
                    self.showAlert(title: "Erorr loading locations", message: "There was an error loading locations")
                    return
                }
                guard locationsArray.count > 0 else {
                    self.showAlert(title: "Error", message: "No pins found")
                    return
                }
                self.students = locationsArray
                
            }
        }
    }
    
    @objc private func logoutClicked(_ sender: Any) {
        let alertController = UIAlertController(title: "Logout", message: "Are you sure you want to logout?", preferredStyle: .alert )
        
        alertController.addAction(UIAlertAction (title: "Logout", style: .default, handler: { _ in
            deleteSession { (err) in
                guard err == nil else {
                    self.showAlert(title: "Error", message: err!)
                    return
                }
                self.dismiss(animated: true, completion: nil)
            }
        }))
        
        alertController.addAction(UIAlertAction (title: "Cancel", style: .destructive, handler:nil))
        
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }

}
